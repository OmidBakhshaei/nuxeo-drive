Add hook for multiprocessing.util to not pull in python test-suite and thus
e.g. tkinter.
