Add hook for zope.interface to not pull in pytest unittests, which will be
rearly used in frozen packages.
