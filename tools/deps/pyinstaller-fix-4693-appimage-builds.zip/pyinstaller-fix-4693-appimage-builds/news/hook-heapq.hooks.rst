Add hook for heapq to not pull in doctests, which is only
required when run as main programm.
