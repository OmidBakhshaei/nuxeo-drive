Add hook for difflib to not pull in doctests, which is only
required when run as main programm.
