Add hook for pickle to not pull in doctests and argpargs, which are only
required when run as main programm.
