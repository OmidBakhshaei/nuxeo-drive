#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "72bdc7b392"     # abbreviated commit hash
commit = "72bdc7b3928813ae78e075d06c5a4f81da690978"  # commit hash
date = "2020-09-30 16:28:05 +0200"   # commit date
author = "Mickaël Schoentgen <contact@tiger-222.fr>"
ref_names = "fix-4693-appimage-builds"  # incl. current branch
commit_message = """building: Fix AppImage builds.

AppImage builds were broken since the commit 392aba1.
"""
