#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "ccecb9488e"     # abbreviated commit hash
commit = "ccecb9488e35b58faf05feb5f2cabeb4f1527db9"  # commit hash
date = "2020-09-30 16:20:09 +0200"   # commit date
author = "Mickaël Schoentgen <contact@tiger-222.fr>"
ref_names = "fix2"  # incl. current branch
commit_message = """m
"""
